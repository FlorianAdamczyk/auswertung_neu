# Attention!

Here we had to use a ND0.4 Filter for the measurements (including)
360K - 460k

To Plot the data correctly, you have to scale the Measurements at theese temperatures by factor 2.571